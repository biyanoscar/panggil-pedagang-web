-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.5.62 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             10.1.0.5464
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table panggil_pedagang.auth_activation_attempts
CREATE TABLE IF NOT EXISTS `auth_activation_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(255) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `token` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table panggil_pedagang.auth_activation_attempts: ~0 rows (approximately)
DELETE FROM `auth_activation_attempts`;
/*!40000 ALTER TABLE `auth_activation_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_activation_attempts` ENABLE KEYS */;

-- Dumping structure for table panggil_pedagang.auth_groups
CREATE TABLE IF NOT EXISTS `auth_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table panggil_pedagang.auth_groups: ~0 rows (approximately)
DELETE FROM `auth_groups`;
/*!40000 ALTER TABLE `auth_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_groups` ENABLE KEYS */;

-- Dumping structure for table panggil_pedagang.auth_groups_permissions
CREATE TABLE IF NOT EXISTS `auth_groups_permissions` (
  `group_id` int(11) unsigned NOT NULL DEFAULT '0',
  `permission_id` int(11) unsigned NOT NULL DEFAULT '0',
  KEY `auth_groups_permissions_permission_id_foreign` (`permission_id`),
  KEY `group_id_permission_id` (`group_id`,`permission_id`),
  CONSTRAINT `auth_groups_permissions_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `auth_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `auth_groups_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `auth_permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table panggil_pedagang.auth_groups_permissions: ~0 rows (approximately)
DELETE FROM `auth_groups_permissions`;
/*!40000 ALTER TABLE `auth_groups_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_groups_permissions` ENABLE KEYS */;

-- Dumping structure for table panggil_pedagang.auth_groups_users
CREATE TABLE IF NOT EXISTS `auth_groups_users` (
  `group_id` int(11) unsigned NOT NULL DEFAULT '0',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0',
  KEY `auth_groups_users_user_id_foreign` (`user_id`),
  KEY `group_id_user_id` (`group_id`,`user_id`),
  CONSTRAINT `auth_groups_users_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `auth_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `auth_groups_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table panggil_pedagang.auth_groups_users: ~0 rows (approximately)
DELETE FROM `auth_groups_users`;
/*!40000 ALTER TABLE `auth_groups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_groups_users` ENABLE KEYS */;

-- Dumping structure for table panggil_pedagang.auth_logins
CREATE TABLE IF NOT EXISTS `auth_logins` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `user_id` int(11) unsigned DEFAULT NULL,
  `date` datetime NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `email` (`email`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Dumping data for table panggil_pedagang.auth_logins: ~2 rows (approximately)
DELETE FROM `auth_logins`;
/*!40000 ALTER TABLE `auth_logins` DISABLE KEYS */;
INSERT INTO `auth_logins` (`id`, `ip_address`, `email`, `user_id`, `date`, `success`) VALUES
	(1, '::1', 'admin@test.com', 1, '2020-10-10 19:36:00', 1),
	(2, '::1', 'admin@test.com', 1, '2020-10-10 19:39:02', 1);
/*!40000 ALTER TABLE `auth_logins` ENABLE KEYS */;

-- Dumping structure for table panggil_pedagang.auth_permissions
CREATE TABLE IF NOT EXISTS `auth_permissions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table panggil_pedagang.auth_permissions: ~0 rows (approximately)
DELETE FROM `auth_permissions`;
/*!40000 ALTER TABLE `auth_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_permissions` ENABLE KEYS */;

-- Dumping structure for table panggil_pedagang.auth_reset_attempts
CREATE TABLE IF NOT EXISTS `auth_reset_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `token` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table panggil_pedagang.auth_reset_attempts: ~0 rows (approximately)
DELETE FROM `auth_reset_attempts`;
/*!40000 ALTER TABLE `auth_reset_attempts` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_reset_attempts` ENABLE KEYS */;

-- Dumping structure for table panggil_pedagang.auth_tokens
CREATE TABLE IF NOT EXISTS `auth_tokens` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `selector` varchar(255) NOT NULL,
  `hashedValidator` varchar(255) NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `expires` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `auth_tokens_user_id_foreign` (`user_id`),
  KEY `selector` (`selector`),
  CONSTRAINT `auth_tokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Dumping data for table panggil_pedagang.auth_tokens: ~0 rows (approximately)
DELETE FROM `auth_tokens`;
/*!40000 ALTER TABLE `auth_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_tokens` ENABLE KEYS */;

-- Dumping structure for table panggil_pedagang.auth_users_permissions
CREATE TABLE IF NOT EXISTS `auth_users_permissions` (
  `user_id` int(11) unsigned NOT NULL DEFAULT '0',
  `permission_id` int(11) unsigned NOT NULL DEFAULT '0',
  KEY `auth_users_permissions_permission_id_foreign` (`permission_id`),
  KEY `user_id_permission_id` (`user_id`,`permission_id`),
  CONSTRAINT `auth_users_permissions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `auth_users_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `auth_permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table panggil_pedagang.auth_users_permissions: ~0 rows (approximately)
DELETE FROM `auth_users_permissions`;
/*!40000 ALTER TABLE `auth_users_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_users_permissions` ENABLE KEYS */;

-- Dumping structure for table panggil_pedagang.categories
CREATE TABLE IF NOT EXISTS `categories` (
  `category_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(255) NOT NULL,
  `category_slug` varchar(255) NOT NULL,
  `category_img` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- Dumping data for table panggil_pedagang.categories: ~8 rows (approximately)
DELETE FROM `categories`;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`category_id`, `category_name`, `category_slug`, `category_img`, `created_at`, `updated_at`) VALUES
	(1, 'Tukang Sayur', 'tukang-sayur', 'vegetables_640.jpg', '2020-10-08 18:34:29', '2020-10-08 18:34:32'),
	(2, 'Tukang Daging', 'tukang-daging', 'beef_640.jpg', '2020-10-08 18:34:30', '2020-10-08 18:34:33'),
	(3, 'Katering', 'katering', 'platter_640.jpg', '2020-10-08 18:34:35', '2020-10-08 18:34:36'),
	(4, 'Minuman', 'minuman', 'drinks_640.jpg', '2020-10-08 18:35:03', '2020-10-08 18:35:04'),
	(5, 'Jasa Servis', 'jasa-servis', 'bicycle_640.jpg', '2020-10-08 18:36:16', '2020-10-08 18:36:17'),
	(6, 'Edukasi', 'edukasi', 'teacher_640.jpg', '2020-10-08 18:36:30', '2020-10-10 02:56:56'),
	(7, 'Potong Rambut', 'potong-rambut', 'haircut_640.jpg', '2020-10-08 18:36:40', '2020-10-08 18:36:41'),
	(8, 'Bengkel', 'bengkel', 'car-repair_640.jpg', '2020-10-08 18:36:50', '2020-10-10 02:07:57');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;

-- Dumping structure for table panggil_pedagang.merchants
CREATE TABLE IF NOT EXISTS `merchants` (
  `merchant_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `merchant_name` varchar(255) NOT NULL,
  `merchant_address` varchar(255) DEFAULT NULL,
  `merchant_phone` varchar(255) NOT NULL,
  `merchant_email` varchar(255) DEFAULT NULL,
  `merchant_slug` varchar(255) NOT NULL,
  `merchant_img` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`merchant_id`),
  KEY `category_id` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- Dumping data for table panggil_pedagang.merchants: ~7 rows (approximately)
DELETE FROM `merchants`;
/*!40000 ALTER TABLE `merchants` DISABLE KEYS */;
INSERT INTO `merchants` (`merchant_id`, `category_id`, `merchant_name`, `merchant_address`, `merchant_phone`, `merchant_email`, `merchant_slug`, `merchant_img`, `created_at`, `updated_at`) VALUES
	(1, 1, 'Sayur Pak Paijo', NULL, '6289611786733', NULL, 'sayur-pak-paijo', 'sayur1.jpeg', '2020-10-09 08:42:10', '2020-10-09 08:42:12'),
	(2, 1, 'Sayur Bu Lastri', NULL, '6285380572545 ', NULL, 'sayur-bu-lastri', 'sayur2.jpg', '2020-10-09 08:43:28', '2020-10-09 08:43:28'),
	(3, 1, 'Sayur Pak Slamet', 'Jl. Setro Baru Utara III No.103 A, Gading, Kec. Tambaksari', '6283875514720', NULL, 'sayur-pak-slamet', 'sayur3.jpeg', '2020-10-09 16:24:59', '2020-10-09 16:25:01'),
	(4, 2, 'Daging Pak Sarimin', NULL, '6285731061555 ', NULL, 'daging-pak-sarimin', 'daging.jpg', '2020-10-09 18:19:38', '2020-10-09 18:19:39'),
	(5, 2, 'Ikan Bu Tukiyem', 'Pasar Ciroyom', '6287861753096 ', NULL, 'ikan-bu-tukiyem', 'penjual-ikan.jpg', '2020-10-09 18:21:17', '2020-10-09 18:21:18'),
	(6, 3, 'Catering Mimi', NULL, '6289607936485 ', NULL, 'catering-mimi', 'catering-mimi.jpg', '2020-10-09 18:33:06', '2020-10-09 18:33:07'),
	(7, 3, 'Nasi Kuning Ridho', NULL, '6285641080311 ', NULL, 'nasi-kuning-ridho', 'nasi-kuning-ridho.jpg', '2020-10-09 18:33:54', '2020-10-09 18:33:54');
/*!40000 ALTER TABLE `merchants` ENABLE KEYS */;

-- Dumping structure for table panggil_pedagang.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` text NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Dumping data for table panggil_pedagang.migrations: ~3 rows (approximately)
DELETE FROM `migrations`;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES
	(1, '2020-10-08-111956', 'App\\Database\\Migrations\\CreateCategoriesTable', 'default', 'App', 1602156574, 1),
	(3, '2020-10-08-121638', 'App\\Database\\Migrations\\CreateMerchantsTable', 'default', 'App', 1602159930, 2),
	(4, '2017-11-20-223112', 'Myth\\Auth\\Database\\Migrations\\CreateAuthTables', 'default', 'App', 1602330631, 3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Dumping structure for table panggil_pedagang.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `reset_hash` varchar(255) DEFAULT NULL,
  `reset_at` datetime DEFAULT NULL,
  `reset_expires` datetime DEFAULT NULL,
  `activate_hash` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `status_message` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `force_pass_reset` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table panggil_pedagang.users: ~1 rows (approximately)
DELETE FROM `users`;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `email`, `username`, `password_hash`, `reset_hash`, `reset_at`, `reset_expires`, `activate_hash`, `status`, `status_message`, `active`, `force_pass_reset`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'admin@test.com', 'admin', '$2y$10$R8DIAb9ZdpoB3TbRNGyfHOPRL8p66iql54D7c5RYWQ6BEWNxtkjmO', NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, '2020-10-10 19:35:43', '2020-10-10 19:35:43', NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
